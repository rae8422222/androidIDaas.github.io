//
//  SceneDelegate.h
//  BICCAMDemo
//
//  Created by 栗子小西 on 2019/12/12.
//  Copyright © 2019 com.bamboocloud.demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

