//
//  ViewController.m
//  BICCAMDemo
//
//  Created by 栗子小西 on 2019/12/12.
//  Copyright © 2019 com.bamboocloud.demo. All rights reserved.
//

#import "ViewController.h"
#import <BCCIAMSDK/BCCIAMSDK.h>
#import "constant.h"
#import <AFNetworking/AFNetworking.h>



#define klogin @"isLogin"
#define kname @"kloginName"
#define kUsername @"kloginUserName"
#define kphone @"kloginPhone"
#define kid @"kLoginId"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString* info=[DEFAULTS objectForKey:klogin];
       if (![info isEqualToString:@"111"]){
           
          
           _logIN.hidden=NO;
           
           _hasNotLoginLabel.hidden=NO;
           _welcomeLabel.hidden=YES;
           _nameLabel.hidden=YES;
           _phoneLabel.hidden=YES;
           _exitBtn.hidden=YES;
           
           
       }else{
           
           _hasNotLoginLabel.hidden=YES;
           _logIN.hidden=YES;
           _welcomeLabel.hidden=NO;
           _nameLabel.hidden=NO;
           _phoneLabel.hidden=NO;
           _exitBtn.hidden=NO;
           _nameLabel.text=[DEFAULTS objectForKey:kname];
           _phoneLabel.text=[DEFAULTS objectForKey:kphone];
           
       }

}
- (IBAction)exitClick:(id)sender {
    
    [DEFAULTS removeObjectForKey:klogin];
       _logIN.hidden=NO;
       
       _hasNotLoginLabel.hidden=NO;
       _welcomeLabel.hidden=YES;
       _nameLabel.hidden=YES;
       _phoneLabel.hidden=YES;
       _exitBtn.hidden=YES;
                  
       self.nameLabel.text=@"";
       self.phoneLabel.text=@"";
      
       [_webView clearWebCache];
    
    
}

- (IBAction)loginClic:(id)sender {
    //https://bc.bccastle.com:443/api/ams/oauth/authorize?response_type=token&client_id=r99zn1c2iyx1o0k2mnj38uab4NyJ4owx&redirect_uri=https://bc.bccastle.com/authentication/index.html&config_id=27dc3205-0446-43c8-be85-69cf50cd7d39
    //http://local.bccastle.com:8081/api/ams/oauth/authorize?response_type=token&client_id=7cVrPkJVVAy56bOg6YUcGs7ZUof3dbSf&redirect_uri=http://local.bccastle.com:8081/authentication/index.html&config_id=a355d244-dfa3-45f8-b8d0-ea3d4d3ee8de
    _webView =[BCWebViewViewController webViewWithLoginUrl:@"https://bc.bccastle.com:443/api/ams/oauth/authorize?response_type=token&client_id=r99zn1c2iyx1o0k2mnj38uab4NyJ4owx&redirect_uri=https://bc.bccastle.com/authentication/index.html&config_id=27dc3205-0446-43c8-be85-69cf50cd7d39" completionHandler:^(NSString * _Nonnull sessionId) {
                [self getUserInfo:sessionId];
                     
                 }];
                 
         
               [self.navigationController pushViewController:_webView animated:YES];
                
}

-(void)getUserInfo:(NSString*)access_token{

    __weak __typeof(self)weakSelf = self;

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

        //调出请求头

        manager.requestSerializer = [AFJSONRequestSerializer serializer];

        //将token封装入请求头

    //固定字段，记住Bearer字段后有个空格
    [manager.requestSerializer setValue: [NSString stringWithFormat:@"Bearer %@",access_token] forHTTPHeaderField:@"Authorization"];
       

        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/html",@"application/json", nil];
    
    [manager GET:@"https://bc.bccastle.com/api/ams/get_user_info" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        __strong __typeof(weakSelf)strongSelf = weakSelf;

        [strongSelf.navigationController popViewControllerAnimated:YES];
        NSDictionary* dict=(NSDictionary*)responseObject;
       NSString* ids= [dict objectForKey:@"id"];
      NSString* phone=[dict objectForKey:@"mobile"];
        NSString* name= [dict objectForKey:@"name"];
        NSString* userName= [dict objectForKey:@"userName"];
        
        if (nil!=name&&![name isEqualToString:@""]) {
            
            strongSelf.hasNotLoginLabel.hidden=YES;
            strongSelf.logIN.hidden=YES;
            strongSelf.welcomeLabel.hidden=NO;
            strongSelf.nameLabel.hidden=NO;
            strongSelf.phoneLabel.hidden=NO;
            strongSelf.exitBtn.hidden=NO;
            
            
            strongSelf.nameLabel.text=name;
            strongSelf.phoneLabel.text=phone;
            
            [DEFAULTS setObject:@"111" forKey:klogin];
            [DEFAULTS setObject:name forKey:kname];
            [DEFAULTS setObject:userName forKey:kUsername];
            [DEFAULTS setObject:phone forKey:kphone];
            [DEFAULTS setObject:ids forKey:kid];
            [DEFAULTS setObject:nil forKey:klogin];
            
        }
       
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        __strong __typeof(weakSelf)strongSelf = weakSelf;

        [strongSelf.navigationController popViewControllerAnimated:YES];
        
        strongSelf.hasNotLoginLabel.text=@"登录不成功！";
    }];
    
}


@end
