//
//  ViewController.h
//  BICCAMDemo
//
//  Created by 栗子小西 on 2019/12/12.
//  Copyright © 2019 com.bamboocloud.demo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BCCIAMSDK/BCCIAMSDK.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *hasNotLoginLabel;
@property (weak, nonatomic) IBOutlet UIButton *logIN;

@property (weak, nonatomic) IBOutlet UILabel *welcomeLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel;
@property (weak, nonatomic) IBOutlet UIButton *exitBtn;

@property(nonatomic,strong)BCWebViewViewController *webView;


@end

