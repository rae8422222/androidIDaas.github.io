//
//  BCCIAMSDK.h
//  BCCIAMSDK
//
//  Created by bald on 2019/7/15.
//  Copyright © 2019 bald. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BCCIAMSDK.
FOUNDATION_EXPORT double BCCIAMSDKVersionNumber;

//! Project version string for BCCIAMSDK.
FOUNDATION_EXPORT const unsigned char BCCIAMSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BCCIAMSDK/BCCIAMSDK.h>
#import <BCCIAMSDK/BCCIAMAuthManager.h>
#import <BCCIAMSDK/BCWebViewViewController.h>
