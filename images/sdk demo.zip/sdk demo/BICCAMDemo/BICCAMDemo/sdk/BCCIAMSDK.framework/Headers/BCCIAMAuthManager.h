//
//  BCOauth.h
//  BCCIAM
//
//  Created by bald on 2019/6/1.
//  Copyright © 2019 com.bamboocloud. All rights reserved.
//

#import <Foundation/Foundation.h>
@class BCCIAMAuthManager;
NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, BCOauthAppType) {
    BCOauthAppTypeQQ = 1,
    BCOauthAppTypeWechat,
    BCOauthAppTypeWeibo,
    BCOauthAppTypeOther
};
@protocol BCOauthDelegate <NSObject>
- (void)oauthManager:(BCCIAMAuthManager *)oauthManager successWithInfo:(NSDictionary *)info;
- (void)oauthManager:(BCCIAMAuthManager *)oauthManager failWithInfo:(NSString *)info;
@end
@interface BCCIAMAuthManager : NSObject
@property (nonatomic,weak)id <BCOauthDelegate> delegate;

/**
 获取当前对象
 */
+ (BCCIAMAuthManager *)sharedInstance;

/**
 设置QQAPP ID
 @return 返回当前对象
 */
- (BCCIAMAuthManager *)setQQAppId:(NSString *)qqAppId;

/**
 设置微信APP ID
 @return 当前对象
 */
- (BCCIAMAuthManager *)setWXAppId:(NSString *)wxAppId;

/**
 设置新浪微博APP ID
 @return 当前对象
 */
- (BCCIAMAuthManager *)setWEIBOAppId:(NSString *)weiboAppId;

/**
 设置QQ回调地址
 
 @param qqRedirectURI QQ回调的URL
 @return 当前对象
 */
- (BCCIAMAuthManager *)setQQRedirectURI:(NSString *)qqRedirectURI;
/**
 设置Weibo回调地址
 
 @param weiboRedirectURI QQ回调的URL
 @return 当前对象
 */
- (BCCIAMAuthManager *)setWEIBORedirectURI:(NSString *)weiboRedirectURI;
/**
 * 处理应用拉起协议
 * \param url 处理被其他应用呼起时的逻辑
 * \return 处理结果，YES表示成功，NO表示失败
 */
- (BOOL)oauthHandleOpenURL:(NSURL *)url;

/**
 通过点击的服务,打开对应的应用进行授权

 @param openType 应用类型
 */
- (void)openWithType:(BCOauthAppType)openType;
@end


NS_ASSUME_NONNULL_END
