//
//  BCWebViewViewController.h
//  BCCIAMSDK
//
//  Created by bald on 2019/7/19.
//  Copyright © 2019 bald. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface BCWebViewViewController : UIViewController<WKUIDelegate, WKNavigationDelegate>
{
@protected
    WKWebView *_webView;
    NSURL *_URL;
}

/**
 webView对象
 */
@property(readonly, nonatomic) WKWebView *webView;

/**
 缓存策略
 */
@property(assign, nonatomic) NSURLRequestCachePolicy cachePolicy;

/**
 获取当前控制器
 */
+ (instancetype)webViewController;

/**
 打开登录页面

 @param loginUrl 登录页面的URL地址
 @param completionHandler 登录完成后的回调
 */
+ (instancetype)webViewWithLoginUrl:(NSString *)loginUrl completionHandler:(nullable void (^)(NSString *sessionId))completionHandler;

/**
 打开用户中心页面

 @param userCenterUrl 用户中心的URL地址
 */
+ (instancetype)webViewWithUserCenterUrl:(NSString *)userCenterUrl;

-(void)clearWebCache;

@end

NS_ASSUME_NONNULL_END
