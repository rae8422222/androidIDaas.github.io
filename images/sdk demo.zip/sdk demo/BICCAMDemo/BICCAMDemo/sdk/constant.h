//
//  constant.h
//  BCCIAMDemo
//
//  Created by 栗子小西 on 2019/11/26.
//  Copyright © 2019 com.bamboocloud.demo. All rights reserved.
//

#ifndef constant_h
#define constant_h


//获取UserDefaults
#define DEFAULTS [NSUserDefaults standardUserDefaults]

#define BASEURL @"https://protest.bccastle.com:443/api/" 


#endif /* constant_h */
